import pandas as pd
import os

input_folder = "D:/data"   
output_folder = "D:/cleaned_data"  

os.makedirs(output_folder, exist_ok=True)

csv_files = [f for f in os.listdir(input_folder) if f.endswith(".csv")]

if not csv_files:
    print("❌ No CSV file was found in the folder")
    exit()

numeric_cols = ['Cost', 'Sales', 'Quantity', 'Total_Cost', 'Total_Sales']

for file_name in csv_files:
    file_path = os.path.join(input_folder, file_name)
    print(f"\n📂 Processing file: {file_name}")
    
    try:
        data = pd.read_csv(file_path, encoding='utf-8')
        print(f"✅ Data loaded! Original number of rows: {len(data)}")
        
        data_cleaned = data.dropna()  # Remove missing values
        data_cleaned = data_cleaned.drop_duplicates()  # Remove duplicates
        
        # Manually handle outliers using Z-Score
        for col in numeric_cols:
            if col in data_cleaned.columns:
                mean_val = data_cleaned[col].mean()
                std_dev = data_cleaned[col].std()
                data_cleaned = data_cleaned[(data_cleaned[col] - mean_val).abs() / std_dev < 3]
        
        # Save the cleaned file with the same name in the new folder
        output_path = os.path.join(output_folder, file_name)
        data_cleaned.to_csv(output_path, index=False, encoding='utf-8-sig')
        
        print(f"💾 Cleaned file saved at: {output_path}")
        print(f"🎯 Number of rows after cleaning: {len(data_cleaned)}")
    
    except Exception as e:
        print(f"❌ Error while processing {file_name}: {e}")

print("\n✅ All files have been cleaned successfully!")
